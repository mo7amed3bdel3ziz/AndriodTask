package com.example.androidtask.data.remote.models

data class Categories(
    var id: Int,
    var name: String,
    var image: String,
    var active: Int
)
