package com.example.androidtask.presentation.home.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.lifecycleScope
import com.example.androidtask.R
import com.example.androidtask.presentation.home.CategoryAdapter
import com.example.androidtask.presentation.home.PopularAdapter
import com.example.androidtask.presentation.home.TrendingAdapter
import com.example.androidtask.data.remote.models.CaregoryItem
import com.example.androidtask.data.remote.models.DataHomeModel
import com.example.androidtask.databinding.ActivityMainBinding
import com.example.androidtask.utils.network.State
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val viewModel: HomeViewModel by viewModels()
    lateinit var token: String
    lateinit var username: String
    var dataHomeModel: ArrayList<DataHomeModel> = arrayListOf()
    val categorySet = HashSet<CaregoryItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        token = intent.getStringExtra("token").toString()
        username = intent.getStringExtra("username").toString()
        binding.nameID.setText("Hello " + username)

        callPopularSeller()
        callTrendingSeller()
        getBaseCategories()
    }

    fun callPopularSeller() {
        lifecycleScope.launch() {
            viewModel.homeVM(
                token,
                29.1931,
                30.6421,
                1
            ).collect {

                when (it) {
                    is State.Loading -> {

                    }

                    is State.Success -> {
                        if (it.data.response_code == 200) {
                            Toast.makeText(applicationContext, it.data.message, Toast.LENGTH_SHORT)
                                .show()

                            it.data.data.forEach { item ->
                                dataHomeModel.add(item)
                            }
                            binding.addressID.setText(dataHomeModel[0].address)
                            val popularAdapter = PopularAdapter()
                            popularAdapter.submitList(dataHomeModel)
                            binding.recyclerView2.adapter = popularAdapter
                            popularAdapter.notifyDataSetChanged()
                        } else {
                            Toast.makeText(this@MainActivity, it.data.message, Toast.LENGTH_SHORT)
                                .show()
                        }
                    }

                    is State.Error -> {
                        Toast.makeText(this@MainActivity, it.messag, Toast.LENGTH_SHORT).show()
                        Log.d("VisitBranchWithoutPay", it.messag + "error")

                    }
                }
            }
        }
    }

    fun callTrendingSeller() {
        lifecycleScope.launch() {
            viewModel.trendingSellersVM(
                token,
                29.1931,
                30.6421,
                1
            ).collect {

                when (it) {
                    is State.Loading -> {

                    }

                    is State.Success -> {
                        if (it.data.response_code == 200) {
                            it.data.data.forEach { item ->
                                dataHomeModel.add(item)
                            }
                            val trendingAdapter = TrendingAdapter()
                            trendingAdapter.submitList(dataHomeModel)
                            binding.recyclerView3.adapter = trendingAdapter
                            trendingAdapter.notifyDataSetChanged()

                        } else {
                            Toast.makeText(this@MainActivity, it.data.message, Toast.LENGTH_SHORT)
                                .show()
                        }
                    }

                    is State.Error -> {
                        Toast.makeText(this@MainActivity, it.messag, Toast.LENGTH_SHORT).show()
                        Log.d("VisitBranchWithoutPay", it.messag + "error")

                    }
                }
            }
        }
    }


    fun getBaseCategories() {
        lifecycleScope.launch() {
            viewModel.getBaseCategoriesVM(
                token
            ).collect {

                when (it) {
                    is State.Loading -> {

                    }

                    is State.Success -> {
                        if (it.data.response_code == 200) {


                            for (i in it.data.data) {
                                categorySet.addAll(listOf(i))
                                Log.d("VisitBranchWithoutPay", "lll" + categorySet.toString())
                            }
                            val adapter = CategoryAdapter()
                            adapter.submitList(categorySet.toList())
                            binding.recyclerView.adapter = adapter
                            adapter.notifyDataSetChanged()

                        } else {
                            Toast.makeText(this@MainActivity, it.data.message, Toast.LENGTH_SHORT)
                                .show()
                        }
                    }

                    is State.Error -> {
                        Toast.makeText(this@MainActivity, it.messag, Toast.LENGTH_SHORT).show()
                        Log.d("VisitBranchWithoutPay", it.messag + "error")

                    }
                }
            }
        }
    }
}