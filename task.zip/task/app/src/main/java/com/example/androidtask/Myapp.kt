package com.example.androidtask

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class Myapp : Application()