package com.example.androidtask.data.remote.models

data class CaregoryItem(
    var id: Int,
    var name: String,
    var image: String,
    var active: Int,
    var name_ar: String,
    var name_en: String
)
