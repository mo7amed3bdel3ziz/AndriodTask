package com.example.androidtask.data.remote.models

data class RequestModel(
    var email: String,
    var password: String,
    var device_token: String
)
